﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_10_FuncionesDu
{
    internal class Funciones_varias
    {
        public static double Suma(double n1, double n2)
        {
            return n1 + n2;
        }
        public static double Resta(double n1, double n2)
        {
            return n1 - n2;
        }
        public static double Producto(double n1, double n2)
        {
            return n1 * n2;
        }

        public static double Division(double n1, double n2)
        {
            return n1 / n2;
        }
    }
}
