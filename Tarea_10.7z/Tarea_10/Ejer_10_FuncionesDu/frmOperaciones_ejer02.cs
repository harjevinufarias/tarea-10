﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer_10_FuncionesDu
{
    public partial class frmOperaciones_ejer02 : Form
    {
        public frmOperaciones_ejer02()
        {
            InitializeComponent();
        }

        private void btnMas_Click(object sender, EventArgs e)
        {
            if (double.TryParse(this.txtNum1.Text, out double num1) && double.TryParse(this.txtNum2.Text, out double num2))
            {
                double res = Ejer_10_FuncionesDu.Funciones_varias.Suma(num1, num2);
                this.txtResultado.Text = res.ToString("n4");
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un número.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            if (double.TryParse(this.txtNum1.Text, out double num1) && double.TryParse(this.txtNum2.Text, out double num2))
            {
                var btn = (Button)sender;
                string aux = btn.Text.ToString();

                double res = 0;
                if (aux == "-")
                    res = Ejer_10_FuncionesDu.Funciones_varias.Resta(num1, num2);
                else if (aux == "x")
                    res = Ejer_10_FuncionesDu.Funciones_varias.Producto(num1, num2);
                else if (aux == "/")
                    res = Ejer_10_FuncionesDu.Funciones_varias.Division(num1, num2);

                this.txtResultado.Text = res.ToString("n4");
            }
            else
            {
                MessageBox.Show("Por favor, ingrese números válidos en los campos de texto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
