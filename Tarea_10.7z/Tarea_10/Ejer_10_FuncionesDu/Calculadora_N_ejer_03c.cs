﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Ejer_10_FuncionesDu.Calculadora_ejer_03;

namespace Ejer_10_FuncionesDu
{
    public partial class Calculadora_N_ejer_03c : Form
    {
        public Calculadora_N_ejer_03c()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtLimite.Text, out int limite))
            {
                // Calcular la sumatoria de la serie
                double resultado = SeriePotencia.CalcularSumatoria(limite);

                // Mostrar el resultado en el TextBox
                txtResultado.Text = resultado.ToString("n4");
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un número válido para el límite de la serie.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
