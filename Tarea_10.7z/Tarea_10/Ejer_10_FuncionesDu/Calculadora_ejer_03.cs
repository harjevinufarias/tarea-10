﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejer_10_FuncionesDu
{
    internal class Calculadora_ejer_03
    {
        public static bool Ecuacion(double a, double b, double c, out double x1, out double x2)
        {
            x1 = 0;
            x2 = 0;

            // Verificar si se pueden calcular los valores
            double discriminante = b * b - 4 * a * c;

            if (discriminante < 0 || a == 0)
            {
                // No se pueden calcular los valores
                return false;
            }
            else
            {
                // Calcular los valores de x1 y x2
                x1 = (-b + Math.Sqrt(discriminante)) / (2 * a);
                x2 = (-b - Math.Sqrt(discriminante)) / (2 * a);

                return true;
            }


        }
        public static string GeneraTabla(int tabla)
        {
            string resultado = "";

            for (int i = 1; i <= 10; i++)
            {
                int multiplicacion = tabla * i;
                resultado += $"{tabla} x {i} = {multiplicacion}\r\n";
            }

            return resultado;
        }


        public static class SeriePotencia
        {
            public static double CalcularPotencia(int baseNumero, int exponente)
            {
                //calcula la potencia de un número
                return Math.Pow(baseNumero, exponente);
            }

            public static double CalcularSumatoria(int limite)
            {
                // realiza la sumatoria de la serie
                double resultado = 0;

                for (int i = 2; i <= limite; i++)
                {
                    resultado += CalcularPotencia(i, i - 1);
                }

                return resultado;
            }
        }
    }
}
