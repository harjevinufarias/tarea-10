﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer_10_FuncionesDu
{
    public partial class TablasMult_ejer03b : Form
    {
        public TablasMult_ejer03b()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtTabla.Text, out int tabla))
            {
                // Generar la tabla de multiplicar
                string resultado = Calculadora_ejer_03.GeneraTabla(tabla);

                // Mostrar el resultado en el TextBox
                txtResultado.Text = resultado;
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un número válido para generar la tabla.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
