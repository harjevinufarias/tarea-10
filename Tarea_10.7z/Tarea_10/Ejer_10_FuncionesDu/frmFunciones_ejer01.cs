﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer_10_FuncionesDu
{
    public partial class frmFunciones_ejer01 : Form
    {
        public frmFunciones_ejer01()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(this.txtNumero.Text=="")
            {
                MessageBox.Show("Ingrese un valor numérico");
                this.txtNumero.Focus();
                return;
            }
            //llamada a la funcion 
            double res  = this.fnEjemplo1(double.Parse(this.txtNumero.Text));
            this.txtResultado.Text = res .ToString();

            //agregar cada resultado al listbox
            this.lstHistorial.Items.Add($"Con x = {this.txtNumero.Text} el resultado es {res.ToString("n4")}");

        }

        private double fnEjemplo1(double x)
        {
            return x/(1+(x*x));  
        }

    }
}
