﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejer_10_FuncionesDu
{
    public partial class frmEcuacionCuadratica_ejer03a : Form
    {
        public frmEcuacionCuadratica_ejer03a()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Leer coeficientes desde los TextBox
            if (double.TryParse(txtValor_a.Text, out double a) &&
                double.TryParse(txtValor_b.Text, out double b) &&
                double.TryParse(txtValor_c.Text, out double c))
            {
                // Calcular la ecuación cuadrática
                if (Calculadora_ejer_03.Ecuacion(a, b, c, out double x1, out double x2))
                {
                    txtResultadoX1.Text = x1.ToString("n4");
                    txtResultadoX2.Text = x2.ToString("n4");
                }

            }
            else
            {
                MessageBox.Show("No se pueden calcular los valores. Verifique los coeficientes.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
